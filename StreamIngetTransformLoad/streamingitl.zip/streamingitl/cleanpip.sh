find lambda -type d -depth 1 -exec rm -r \{\} \;
