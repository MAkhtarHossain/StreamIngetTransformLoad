#!/usr/bin/env bash
S3Bucket=maitreyr-streamingitl
REGION=us-east-2

FILE="$(uuidgen).yaml"
cd lambda/
pip3 install -r requirements.txt -t "$PWD" --upgrade
cd ..
aws cloudformation package --region $REGION --template-file stream_ingestion_with_transformations.template --s3-bucket $S3Bucket --s3-prefix serverless/firehose --output-template-file $FILE
aws cloudformation deploy --region $REGION --template-file $FILE --stack-name StreamingITL --capabilities CAPABILITY_NAMED_IAM
