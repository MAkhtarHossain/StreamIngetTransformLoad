TRANSFORM=$1


echo 'Stats for Total Messages'
gzcat `find $TRANSFORM -type file -name "*.gz"` | egrep -o "Successfully processed \d*" | cut -d ' ' -f 3 | ruby stats.rb

echo 'Stats for Billed Duration'
gzcat `find $TRANSFORM -type file -name "*.gz"` | egrep -o "Billed Duration: \d*" | cut -d ' ' -f 3 | ruby stats.rb

echo 'Total Log Size'
gzcat `find $TRANSFORM -type file -name "*.gz"` | wc -c

exit

echo 'Stats for Lambda Duration-Sum'
cut -d ',' -f 10 AWS/Lambda-StreamProcessor.csv | grep "^[0-9]" | ruby stats.rb

echo 'Stats for Lambda Invocations-Sum'
cut -d ',' -f 30 AWS/Lambda-StreamProcessor.csv | grep "^[0-9]" | ruby stats.rb

echo 'Stats for Kinesis IncomingRecords-Sum'
cut -d ',' -f 41 AWS/Kinesis-IngestStream.csv | grep "^[0-9]" | ruby stats.rb

echo 'Stats for Kinesis IncomingBytes-Sum'
cut -d ',' -f 36 AWS/Kinesis-IngestStream.csv | grep "^[0-9]" | ruby stats.rb

