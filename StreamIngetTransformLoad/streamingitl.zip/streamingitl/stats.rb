require 'descriptive_statistics'

data = [];

ARGF.each do |line|
  data << line.to_f;
end

#print(data.descriptive_statistics);


printf("N=\t%d\n", data.length);
printf("sum=\t%10.9f\n", data.sum);
printf("min=\t%10.9f\n", data.min);
printf("mean=\t%10.9f\n", data.mean);
printf("p50=\t%10.9f\n", data.median);
printf("p75=\t%10.9f\n", data.percentile(75));
printf("p90=\t%10.9f\n", data.percentile(90));
printf("p99=\t%10.9f\n", data.percentile(99));
printf("p99.9=\t%10.9f\n", data.percentile(99.9));
printf("p99.99=\t%10.9f\n", data.percentile(99.99));
printf("max=\t%10.9f\n", data.max);
printf("stddev=\t%10.9f\n", data.standard_deviation);
