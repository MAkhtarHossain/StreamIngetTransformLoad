import base64
import boto3
import json
import time
import os
from datetime import datetime

# X-Ray SDK: instrument all SDKs
from aws_xray_sdk.core import xray_recorder
from aws_xray_sdk.core import patch_all
patch_all()


# default encoding of bytes in the posted record
ENCODING = 'utf-8'

# cache timeout in seconds
CACHE_TIMEOUT = 15*60 # 15 minutes

# DDB Table name
TABLE_NAME = os.environ['TABLE_NAME']

# in-memory cache of device details with expiry
device_details_cache = {}

print('Loading function')
ddb = boto3.resource('dynamodb')

def getDeviceDetailsFromCache(device_id):
    if device_id in device_details_cache:
        cached = device_details_cache[device_id]
        exp = cached['expiry']
        now = time.time()
        if(now < exp):
            return cached['data']
    return None

def setDeviceDetailsInCache(device_id, details):
    exp = time.time() + CACHE_TIMEOUT
    device_details_cache[device_id] = {
      'expiry' : exp,
      'data' : details
    }

def getDeviceDetails(device_id_set):
    response = {}
    query_device_ids = []

    for device_id in device_id_set:
        device_details = getDeviceDetailsFromCache(device_id)
        if(device_details is None):
            query_device_ids.append(device_id)
        else:
            response[device_id] = device_details

    if len(query_device_ids) > 0:
        queryDDB(query_device_ids, response)
    return response

# DDB Batch Size Max
DDB_BATCH_SIZE = 100
def queryDDB(device_id_list, response):
    unprocessed = []
    print("Querying details for {} devices from DynamoDB".format(len(device_id_list)))

    for i in range(0, len(device_id_list), DDB_BATCH_SIZE):
        keys = []
        j = i
        while j < len(device_id_list) and j < (i + DDB_BATCH_SIZE):
            device_id = device_id_list[j]
            j += 1
            keys.append({
                'device_id' : device_id
            })


        result = ddb.batch_get_item(
            RequestItems = {
                TABLE_NAME : {
                    'Keys' : keys
                }
            }
        )

        for r in result['Responses'][TABLE_NAME]:
            device_id = r['device_id']

            device_details = {
                'manufacturer' : r['manufacturer'],
                'model' : r['model']
            }

            setDeviceDetailsInCache(device_id, device_details)
            response[device_id] = device_details

        unproc_count = 0
        if TABLE_NAME in result['UnprocessedKeys']:
            unproc = len(result['UnprocessedKeys'][TABLE_NAME])
            unproc_count = len(result['UnprocessedKeys'][TABLE_NAME])
            unprocessed.append(unproc)

        print("DDB Query: {} results, {} unprocessed out of {} keys".format(
            len(result['Responses'][TABLE_NAME]),
            unproc_count,
            len(keys)))

    #TODO: handle these via exponential retry
    #print('Unprocessed: ' + json.dumps(unprocessed))


def lambda_handler(event, context):
    source_records = []
    query_devices = set()

    print("Received batch of {} records".format(len(event['records'])))

    for record in event['records']:
        payload = base64.b64decode(record['data']).decode(ENCODING)

        event = json.loads(payload)

        source_records.append({
            'recordId' : record['recordId'],
            'event' : dict(event) # copy of event
        })

        query_devices.add(event['device_id'])

    device_details = getDeviceDetails(query_devices)

    output = []
    successes = 0

    for record in source_records:
        event = record['event']
        device_id = event['device_id']

        if(device_id in device_details):
            # we have device details
            details = device_details[device_id]

            # copy existing event
            trans_event = dict(event)

            # convert timestamp to human readable ISO8601 string
            trans_event['timestamp'] = datetime.utcfromtimestamp(event['timestamp']/1000).isoformat()

            # enrich event with device details
            trans_event['manufacturer'] = details['manufacturer']
            trans_event['model'] = details['model']

            trans_payload = json.dumps(trans_event) + "\n"

            output_record = {
                'recordId': record['recordId'],
                'result': 'Ok',
                'data': base64.b64encode(trans_payload.encode(ENCODING)).decode(ENCODING)
            }
            successes += 1
            output.append(output_record)
        else:
            # we couldn't get device details: flag that as an error to firehose
            output_record = {
                'recordId': record['recordId'],
                'result': 'ProcessingFailed',
                'data': None
            }
            output.append(output_record)

    print('Successfully processed {} out of {} records.'.format(successes, len(source_records)))
    return {'records': output}
